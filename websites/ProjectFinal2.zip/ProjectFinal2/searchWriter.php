<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="homePage.css">
  </head>
  <body>
    <?php

    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>




    <nav class="navbar navbar-light bg-light" id="navH">
     <div class="container-fluid">
       <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
        <span class="motto"> make it possible</span>
        <?php
        $details = $_SESSION['sessionUser'];
        $sql="SELECT Name FROM tblreaders WHERE Username='$details'";
        $result=mysqli_query($connect, $sql);
        $row=mysqli_fetch_array($result);
    echo "<h1>".$row['Name']."</h1>";

         ?>
     </div>
   </nav>

   <nav class="navbar navbar-expand-lg   nav1">
     <div class="container-fluid  navbar-dark bg-dark nav2">
         <div class="navbar-nav nav3 navbar-dark bg-dark ">
           <a class="nav-link "  href="homePage.php">News Feed</a>
           <a class="nav-link " href="searchArticle.php">Search an Article</a>
           <a class="nav-link active" href="newArticle.php">Search a writer</a>
         </div>

     </div>
   </nav>

   <div class="formCenter">
     <form class="d-flex form1" action="searchWriter.php" method="post">
        <input name="searchBar" class="form-control me-2 len" type="search" placeholder="Search Writer" aria-label="Search">
        <button name="search" class="btn btn-outline-success" type="submit">Search</button>
     </form>
   </div>
   <?php
if (isset($_POST["search"])) {
$search = $_POST['searchBar'];
 $sql= " SELECT * FROM tblwriters WHERE Username = '$search' ";
   //running the query
   $results= mysqli_query($connect, $sql);

   if($results)
    {
      if($results->num_rows > 0)
      {
        ?>
           <table >
                   <tr>

                       <td class="heading">title</td>

                   </tr>
         <?php
         $counter=0;
               while($row = mysqli_fetch_array($results))
               {
                   $counter++;
                  ?>
                 <tr>


                     <td>
                        <div class="container-fluid titles">
                         <span class="titles" style="color: white;"><a href="searchArticle.php?view=<?php print $row->User_id; ?>"><?php print  $row['Username']?></a></span>
                       </div>
                         </td>
                       </tr>

                 <?php
               }
         ?>
       </table>
       <?php
     }else
      {
       print " no records found on the database" ;
     }
   }
   }

  ?>

 </form>



    </body>
</html>
