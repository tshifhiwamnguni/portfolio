<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="homePage.css">
    <link rel="stylesheet" href="more.css">
  </head>
  <body>
    <?php

    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>

    <nav class="navbar navbar-light bg-light" id="navH">
     <div class="container-fluid">
       <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
        <span class="motto"> make it possible</span>
        <?php
        $details = $_SESSION['sessionUser'];
        $sql="SELECT Name FROM tblreaders WHERE Username='$details'";
        $result=mysqli_query($connect, $sql);
        $row=mysqli_fetch_array($result);
    echo "<h1>".$row['Name']."</h1>";

         ?>
     </div>
   </nav>

   <nav class="navbar navbar-expand-lg  nav1">
     <div class="container-fluid  navbar-dark bg-dark nav2">
         <div class="navbar-nav nav3 ">
        <a class="nav-link "  style="margin-left:35%;"  href="homePage.php">News Feed</a>
         </div>
     </div>
   </nav>
   <form class="readerSideForm needs-validation" action="readerProfiles.php" method="post"  >
   <div class="form2">
     <div  class="form2">
       <h1 style="margin-left:35%;">Update profile</h1>
         <label for="exampleFormControlInput1" class="form-label">Username</label>
         <input type="text" class="form-control" name="readerUsername" placeholder="jamesonSelect16">
         <label for="exampleFormControlInput1" class="form-label">full names</label>
         <input type="text" class="form-control" name="readerFN" placeholder="john jameson">
         <label for="exampleFormControlInput1" class="form-label">Password</label>
         <input type="password" class="form-control" name="readerPassword" placeholder="Password">
         <button type="submit" class="btn btn-info" style="margin-left:40%; margin-top:10px;" name="update">update</button><br>

     </div>
   </div>
   </form>

   <?php
   if (isset($_POST["update"])) {
     $readerUsername = $_POST['readerUsername'];
     $readerFm = $_POST['readerFN'];
     $readerPassword = $_POST['readerPassword'];
     //add slashes
     //create an sql statement
     $sql = "UPDATE tblreaders SET Username = '$readerUsername', Name ='$readerFm', Password = '$readerPassword' WHERE Username ='$details' ";
       //run it
       $result = mysqli_query($connect,$sql);
       echo mysqli_affected_rows($connect);
       if(mysqli_affected_rows($connect) > 0) {

           echo "Data saved successfully";
         }else
         {
           echo mysqli_connect_error();
         }

   }
?>


  </body>
</html>
