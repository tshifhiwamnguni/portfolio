<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="homePage.css">
  </head>
  <body>
    <?php

    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>




    <nav class="navbar navbar-light bg-light top" >
     <div class="container-fluid top">
       <span class="navbar-brand mb-0 h1 top" style="color: white;">DesingFX</span>
        <span class="motto"> make it possible</span>

      <a class="nav-link active"    href="readerProfiles.php">
        <?php
        $details = $_SESSION['sessionUser'];
        $sql="SELECT Name FROM tblreaders WHERE Username='$details'";
        $result=mysqli_query($connect, $sql);
        $row=mysqli_fetch_array($result);
    echo "<h1>".$row['Name']."</h1>";

         ?>
       </a>
     </div>
   </nav>

   <nav class="navbar navbar-expand-lg  nav1">
     <div class="container-fluid  navbar-dark bg-dark nav2">
         <div class="navbar-nav nav3 ">
           <a class="nav-link active"    href="homePage.php">News Feed</a>
           <a class="nav-link " href="searchArticle.php">Search an Article</a>
           <a class="nav-link" href="searchWriter.php">Search a writer</a>
         </div>

     </div>
   </nav>
   <form class="" action="homePage.php" method="post">
   <?php

$sql33 = "SELECT * FROM tblarticles";
$results=mysqli_query($connect, $sql33);

$storeResults = mysqli_fetch_all($results,MYSQLI_ASSOC);
foreach($storeResults as $article){
    $articleTitleTitle = $article['Title'];
?>
<form action="homePage.php" method="POST">
    <div class="container" style="background-color:lightblue;margin-top:60px">
        <p> <b>Title</b> <?php echo($article['Title']) ?> </p>
        <p><b>Author</b> <span><?php echo($article['Username']) ?></span></p>
        <input type="hidden" id="viewPost" name="go" value="<?php echo("$articleTitleTitle")?>">
        <input type="submit" value="view" name="view">
    </div>
    
</form>
<br>
<?php } ?>

   </form>
<?php


if(isset($_POST['view'])){
  $viewPost = $_POST['go'];
  $_SESSION["article"] = $viewPost;
  header("Location: comments.php");
}?>

    </body>
</html>
