<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="homePage.css">
  </head>
  <body>
    <?php
    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>




    <nav class="navbar navbar-light bg-light" id="navH">
     <div class="container-fluid">
       <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
        <span class="motto"> make it possible</span>
        <?php
        $details = $_SESSION['sessionUser'];
        $sql="SELECT Name FROM tblwriters WHERE Username='$details'";
        $result=mysqli_query($connect, $sql);
        $row=mysqli_fetch_array($result);
    echo "<h1>".$row['Name']."</h1>";

         ?>
     </div>
   </nav>

   <nav class="navbar navbar-expand-lg  nav1">
     <div class="container-fluid  navbar-dark bg-dark nav2">
         <div class="navbar-nav nav3 ">
           <a class="nav-link "    href="writerHome.php">News Feed</a>
           <a class="nav-link active" href="searchArticleWrote.php">Search article wrote</a>
           <a class="nav-link" href="newArticle.php">write new article</a>
         </div>

     </div>
   </nav>

      <div class="formCenter">
        <form class="d-flex form1" action="searchArticleWrote.php" method="post">
           <input name="writerSearchBar" class="form-control me-2 len" type="search" placeholder="Search an article" aria-label="Search">
           <button name="writerSearch" class="btn btn-outline-success" type="submit">Search article</button>
        </form>
      </div>
      <form class="" action="searchArticleWrote.php" method="post">

        <?php
   if (isset($_POST["writerSearch"])) {
     echo "love";
     $search = $_POST['writerSearchBar'];
  $sql33 = "SELECT * FROM tblarticles WHERE  Title='$search'";
  $results=mysqli_query($connect, $sql33);
  
  $storeResults = mysqli_fetch_all($results,MYSQLI_ASSOC);
  foreach($storeResults as $article){
      $articleTitleTitle = $article['Title'];
  ?>
  <form action="searchArticleWrote.php" method="POST">
      <div class="container" style="background-color:lightblue;margin-top:60px">
          <p> <b>Title</b> <?php echo($article['Title']) ?> </p>
          <p><b>Content</b> <span><?php echo($article['Content']) ?></span></p>
          <input type="hidden" id="deleteHidden" name="deletePost" value="<?php echo("$articleTitleTitle")?>">
          <input type="submit" value="Delete Post" name="deleteBtn">
      </div>
      
  </form>
  <br>
  <?php } ?>
  
     </form>
        <?php
   }
        
       ?>
<?php


if(isset($_POST['deleteBtn'])){
  $deletePost = $_POST['deletePost'];
  $deleteSql = "DELETE FROM tblarticles WHERE title = '$deletePost';";
  if(mysqli_query($connect,$deleteSql)){
      echo("<script>alert('post deleted successfuly')</script>");
  }
  else{
      echo("<script>alert('failed to delete the post')</script>");
  }
}?>
   



  </body>
</html>