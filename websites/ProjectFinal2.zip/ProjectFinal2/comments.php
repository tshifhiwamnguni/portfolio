<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="homePage.css">
    <link rel="stylesheet" href="more.css">
  </head>
  <body>
    <body>
      <?php

      session_start();
      $host="localhost";
      $username="root";
      $password="";
      $db_name="desingfxdb";
      $message = "";

        // connextion
        $connect =  mysqli_connect($host , $username , $password , $db_name);
        if (mysqli_connect_error())
         {
           die("Error connecting to the database : ".mysqli_connect_error());
         }
       ?>

       <?php
       $article = $_SESSION["article"];
     $sql= " SELECT * FROM tblarticles WHERE Title = '$article' ";
       //running the query
       $results= mysqli_query($connect, $sql);
       $rowArticle= mysqli_fetch_array($results);
       ?>


           <nav class="navbar navbar-light bg-light" id="navH">
            <div class="container-fluid">
              <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
               <span class="motto"> make it possible</span>
               <?php
               $details = $_SESSION['sessionUser'];
               $sql="SELECT Name FROM tblreaders WHERE Username='$details'";
               $result=mysqli_query($connect, $sql);
               $row=mysqli_fetch_array($result);
           echo "<h1>".$row['Name']."</h1>";

                ?>
            </div>
          </nav>

          <nav class="navbar navbar-expand-lg  nav1">
            <div class="container-fluid  navbar-dark bg-dark nav2">
                <div class="navbar-nav nav3 ">
                  <a class="nav-link "  style="margin-left:35%;"  href="homePage.php">News Feed</a>
                </div>
            </div>
          </nav>





       <h1 class="mid"><?php print $rowArticle['Title']  ?></h1>
       <main class="mid">
         <?php print $rowArticle['Content'] ?>

       </main>
       <form class="form2 " action="comments.php" method="post">
           <div class="nav1" >
             <div class="">

               <label  class="form-label ">comments</label>
                <textarea name="comments" class="form-control " id="exampleFormControlTextarea1" rows="3"></textarea>
                <button name="comment" type="submit" class= "btn btn-secondary mid" style="margin-top:10px;">comment</button>
             </div>
             </div>
       </form>
       <form class="" action="comments.php" method="post">
         <?php
         $sql= " SELECT * FROM tblcomments WHERE CommentGroup = '$article' ";
         //running the query
         $results= mysqli_query($connect, $sql);

         if($results)
          {
            if($results->num_rows > 0)
            {
              ?>
                 <table >

               <?php
               $counter=0;
                     while($rowC = mysqli_fetch_array($results))
                     {
                         $counter++;
                        ?>
                       <tr>

                           <td style="margin-right:2000px;"><?php print  $rowC['Username']  ?></td>
                           <td><?php print  $rowC['Comment']?></td>

                           </tr>
                       <?php
                     }
               ?>
             </table>
             <?php
           }
         }
           else
            {
             print " no records found on the database" ;
           }
        ?>
       </form>

<?php
    if (isset($_POST["comment"])) {
        $comment = $_POST['comments'];
        $date = date("d/m/y");
        $sql = "INSERT INTO tblcomments (CommentGroup, Username , Comment , Dates) VALUES ('$article','$details', '$comment' , '$date')";
        //run it
        $result = mysqli_query($connect,$sql);
        echo mysqli_affected_rows($connect);
        if(mysqli_affected_rows($connect) > 0) {

            echo "Data saved successfully";
              header("Refresh:0");
          }else
          {
            echo mysqli_connect_error();
          }

    }

 ?>

  </body>
</html>
