<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="index.css">
  </head>
  <body>
    <?php

    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>




    <!-- As a heading -->
     <nav class="navbar navbar-light bg-light" id="navH">
      <div class="container-fluid">
        <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
      </div>
    </nav>


    <form class="writerSideForm needs-validation " action="index.php" method="post"  style="float: left" novalidate>
    <div class="writerSide">
      <div >
        <h1>Writer</h1>
          <label   class="form-label">Username</label>
          <input name="writerUser" type="text" class="form-control" id="validationDefault01" placeholder="johnDoe16">
          <label class="form-label">Password</label>
          <input name="writerPass" type="password" class="form-control" id="validationDefault02" placeholder="Password">
          <button name="writerSign" type="submit" class="btn btn-secondary">Sign in</button><br>
          <span class="centerLink">wan to be a writer? <a href="writerReg.php">Register</a></span>

      </div>
    </div>
      </form>


    <form class="readerSideForm needs-validation" action="index.php" method="post"   style="float: right" novalidate>
    <div class="readerSide">
      <div >
        <h1>Reader</h1>
          <label  class="form-label">Username</label>
          <input name="readerUser" type="text" class="form-control" id="validationTooltip01" placeholder="johnDoe16">
          <label  class="form-label">Password</label>
          <input name="readerPass"type="password" class="form-control" id="validationTooltip01" placeholder="Password">
          <button name="readerSign" type="submit" class="btn btn-info">Sign in</button><br>
          <span class="centerLink">wan to be a Reader? <a href="readerReg.php">Register</a></span>
      </div>
    </div>
    </form>





    <?php

      if (isset($_POST["writerSign"])) {
          // Define $writerUser and $writerPassword
          $writerUser=$_POST['writerUser'];
          $writerPassword=$_POST['writerPass'];
          // To protect MySQL injection (more detail about MySQL injection)
          $writerUser = stripslashes($writerUser);
          $writerPassword = stripslashes($writerPassword);
          $writerUser = mysqli_real_escape_string($connect, $writerUser);
          $writerPassword = mysqli_real_escape_string($connect, $writerPassword);
          $sql="SELECT * FROM tblwriters WHERE Username='$writerUser' and Password='$writerPassword'";
          $result=mysqli_query($connect, $sql);
          // Mysql_num_row is counting table row
          $count=mysqli_num_rows($result);
          // If result matched $writerUser and $writerPassword, table row must be 1 row
          if($count==1){
              // Register $writerUser, $writerPassword and redirect to file "login_success.php"
              $_SESSION['sessionUser'] = $_POST['writerUser'];
              header("location:WriterHome.php");
          }
          else {
              echo "Wrong Username or Password";
          }
        }
        if (isset($_POST["readerSign"])) {
            // Define $writerUser and $writerPassword
            $readerUser=$_POST['readerUser'];
            $readerPassword=$_POST['readerPass'];
            // To protect MySQL injection (more detail about MySQL injection)
            $readerrUser = stripslashes($readerUser);
            $readerPassword = stripslashes($readerPassword);
            $readerUser = mysqli_real_escape_string($connect, $readerUser);
            $readerPassword = mysqli_real_escape_string($connect, $readerPassword);
            $sql="SELECT * FROM tblreaders WHERE Username='$readerUser' and Password='$readerPassword'";
            $result=mysqli_query($connect, $sql);
            // Mysql_num_row is counting table row
            $count=mysqli_num_rows($result);
            // If result matched $writerUser and $writerPassword, table row must be 1 row
            if($count==1){
                // Register $writerUser, $writerPassword and redirect to file "login_success.php"
                $_SESSION['sessionUser'] = $_POST['readerUser'];
                header("location:homePage.php");
            }
            else {
                echo "Wrong Username or Password";
            }
          }
        ob_end_flush();
     ?>



  </body>
</html>
