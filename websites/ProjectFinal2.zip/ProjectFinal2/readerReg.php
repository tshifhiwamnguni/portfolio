<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="readerReg.css">
  </head>
  <body>
    <?php

    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $tbl_name="tblwriters";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>
    <form class="readerSideForm needs-validation" action="readerReg.php" method="post"  >
    <div class="readerSide">
      <div >
        <h1 class="">Reader</h1>
          <label for="exampleFormControlInput1" class="form-label">Username</label>
          <input name="readerUsername" type="text" class="form-control" placeholder="jamesonSelect16">
          <label for="exampleFormControlInput1" class="form-label">full names</label>
          <input name="readerFN" type="text" class="form-control"  placeholder="john jameson">
          <label for="exampleFormControlInput1" class="form-label">Date of birth</label>
          <input name="dates"  type="date" class="form-control"  placeholder="1999-16-2">
          <label for="exampleFormControlInput1" class="form-label">Password</label>
          <input name="readerPassword" type="password" class="form-control"  placeholder="Password">
          <button type="submit" class="btn btn-info" name="readerRegBtn">Register</button><br>

      </div>
    </div>
    </form>
    <?php
    if (isset($_POST["readerRegBtn"])) {

        //collect information from the table
        $readerUsername = $_POST['readerUsername'];
        $readerFm = $_POST['readerFN'];
        $dates = $_POST['dates'];
        $readerPassword = $_POST['readerPassword'];
        //add slashes
        //create an sql statement
        $sql = "INSERT INTO tblreaders (Username , Name , DateOfBirth, Password) VALUES ('$readerUsername', '$readerFm' , '$dates', '$readerPassword')";
        //run it
        $result = mysqli_query($connect,$sql);
        echo mysqli_affected_rows($connect);
        if(mysqli_affected_rows($connect) > 0) {

            echo "Data saved successfully";
          }else
          {
            echo mysqli_connect_error();
          }

    }

     ?>
  </body>
</html>
