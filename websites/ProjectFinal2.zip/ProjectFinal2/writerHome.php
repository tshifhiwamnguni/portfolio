<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <link rel="stylesheet" href="bootstrap.css">
  <link rel="stylesheet" href="homePage.css">
  <body>
    <?php

    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>




    <nav class="navbar navbar-light bg-light" id="navH">
     <div class="container-fluid">
       <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
        <span class="motto"> make it possible</span>
        <a class="nav-link active"    href="writerProfiles.php">
        <?php
        $details = $_SESSION['sessionUser'];
        $sql="SELECT Name FROM tblwriters WHERE Username='$details'";
        $result=mysqli_query($connect, $sql);
        $row=mysqli_fetch_array($result);
         echo "<h1>".$row['Name']."</h1>";

         ?></a>
     </div>
   </nav>

   <nav class="navbar navbar-expand-lg  nav1">
     <div class="container-fluid  navbar-dark bg-dark nav2">
         <div class="navbar-nav nav3 ">
           <a class="nav-link active"    href="writerHome.php">News Feed</a>
           <a class="nav-link " href="searchArticleWrote.php">Search article wrote</a>
           <a class="nav-link" href="newArticle.php">write new article</a>
         </div>

     </div>
   </nav>
   <form class="" action="writerHome.php" method="post">
   <?php

$sql33 = "SELECT * FROM tblarticles WHERE  Username='$details'";
$results=mysqli_query($connect, $sql33);

$storeResults = mysqli_fetch_all($results,MYSQLI_ASSOC);
foreach($storeResults as $article){
    $articleTitleTitle = $article['Title'];
?>
<form action="writerHome.php" method="POST">
    <div class="container" style="background-color:lightblue;margin-top:60px">
        <p> <b>Title</b> <?php echo($article['Title']) ?> </p>
        <p><b>Content</b> <span><?php echo($article['Content']) ?></span></p>
        <input type="hidden" id="deleteHidden" name="deletePost" value="<?php echo("$articleTitleTitle")?>">
        <input type="submit" value="Delete Post" name="deleteBtn">
    </div>
    
</form>
<br>
<?php } ?>

   </form>
<?php


if(isset($_POST['deleteBtn'])){
  $deletePost = $_POST['deletePost'];
  $deleteSql = "DELETE FROM tblarticles WHERE title = '$deletePost';";
  if(mysqli_query($connect,$deleteSql)){
      echo("<script>alert('post deleted successfuly')</script>");
  }
  else{
      echo("<script>alert('failed to delete the post')</script>");
  }
}?>

  </body>
</html>
