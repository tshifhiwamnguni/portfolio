<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="homePage.css">
    <link rel="stylesheet" href="more.css">
  </head>
  <body>
    <?php

    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>




    <nav class="navbar navbar-light bg-light" id="navH">
     <div class="container-fluid">
       <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
        <span class="motto"> make it possible</span>
        <?php
        $details = $_SESSION['sessionUser'];
        $sql="SELECT Name FROM tblwriters WHERE Username='$details'";
        $result=mysqli_query($connect, $sql);
        $row=mysqli_fetch_array($result);
    echo "<h1>".$row['Name']."</h1>";

         ?>
     </div>
   </nav>

   <nav class="navbar navbar-expand-lg  nav1">
     <div class="container-fluid  navbar-dark bg-dark nav2">
         <div class="navbar-nav nav3 ">
           <a class="nav-link "    href="writerHome.php">News Feed</a>
           <a class="nav-link  " href="searchArticleWrote.php">Search article wrote</a>
           <a class="nav-link active" href="newArticle.php">write new article</a>
         </div>

     </div>
   </nav>


   <form class="form2 " action="newArticle.php" method="post">
       <div class="nav1" >
         <div class="">
           <h1 class="titles">New article</h1>
           <label class="form-label ">Title</label>
           <input name="title" type="text" class="form-control " placeholder="title...">
           <label  class="form-label ">content</label>
            <textarea name="contents" class="form-control " id="exampleFormControlTextarea1" rows="10"></textarea>
            <button name="newArticle" type="submit" class= "btn btn-secondary mid" style="margin-top:10px;">UPLOAD</button>
         </div>
         </div>
   </form>

   <?php
   if (isset($_POST["newArticle"])) {
     $title = $_POST['title'];
     $contents =$_POST['contents'];
     $date = date("y/m/d");
       $sql = "INSERT INTO tblarticles (Username , Title , Content, Dates) VALUES ('$details', '$title' , '$contents', '$date')";
       //run it
       $result = mysqli_query($connect,$sql);
       echo mysqli_affected_rows($connect);
       if(mysqli_affected_rows($connect) > 0) {

           echo "Data saved successfully";
         }else
         {
           echo mysqli_connect_error();
         }

   }

    ?>

  </body>
</html>
