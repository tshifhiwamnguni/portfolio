<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
      <link rel="stylesheet" href="writerReg.css">
  </head>
  <body>
    <?php

    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $tbl_name="tblwriters";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>
    <form class="writerSideForm needs-validation" action="writerReg.php" method="post" >
    <div class="writerSide">
      <div >
        <h1 class="middle">Writer</h1>
        <label class="form-label">Username</label>
        <input name="writerUsername" type="text" class="form-control" id="validationTooltip01" placeholder="jamesonSelect16">
        <label  class="form-label">full names</label>
        <input name="writerFN" type="text" class="form-control" id="validationTooltip01" placeholder="john jameson">
        <label class="form-label">Company</label>
        <input name="company" type="text" class="form-control" id="validationTooltip01" placeholder="designFX">
        <label  class="form-label">Password</label>
        <input name="writerPassword" type="password" class="form-control" id="validationTooltip01" placeholder="Password">
          <button type="submit" class="btn btn-secondary" name="writerRegBtn">Register</button><br>
      </div>

  </div>
      </form>

<?php
if (isset($_POST["writerRegBtn"])) {

    //collect information from the table
    $writerUsername = $_POST['writerUsername'];
    $writerFm = $_POST['writerFN'];
    $company = $_POST['company'];
    $writerPassword = $_POST['writerPassword'];
    //add slashes
    //create an sql statement
    $sql = "INSERT INTO tblwriters (Username , Name , CompanyName, Password) VALUES ('$writerUsername', '$writerFm' , '$company', '$writerPassword')";
    //run it
    $result = mysqli_query($connect,$sql);
    echo mysqli_affected_rows($connect);
    if(mysqli_affected_rows($connect) > 0) {

        echo "Data saved successfully";
      }else
      {
        echo mysqli_connect_error();
      }

}

 ?>


  </body>
</html>
