<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="homePage.css">
    <link rel="stylesheet" href="more.css">
  </head>
  <body>
    <?php

    session_start();
    $host="localhost";
    $username="root";
    $password="";
    $db_name="desingfxdb";
    $message = "";

      // connextion
      $connect =  mysqli_connect($host , $username , $password , $db_name);
      if (mysqli_connect_error())
       {
         die("Error connecting to the database : ".mysqli_connect_error());
       }
     ?>




    <nav class="navbar navbar-light bg-light" id="navH">
     <div class="container-fluid">
       <span class="navbar-brand mb-0 h1" style="color: white;">DesingFX</span>
        <span class="motto"> make it possible</span>
        <?php
        $details = $_SESSION['sessionUser'];
        $sql="SELECT Name FROM tblwriters WHERE Username='$details'";
        $result=mysqli_query($connect, $sql);
        $row=mysqli_fetch_array($result);
    echo "<h1>".$row['Name']."</h1>";

         ?>
     </div>
   </nav>

   <nav class="navbar navbar-expand-lg  nav1">
     <div class="container-fluid  navbar-dark bg-dark nav2">
         <div class="navbar-nav nav3 ">
           <a class="nav-link "  style="margin-left:35%;"  href="writerHome.php">News Feed</a>
         </div>
     </div>
   </nav>

   <form class="" action="writerProfiles.php" method="post">
     <div class="form2">
       <div class="form2">
         <h1 class="" style="margin-left:35%;">update profile</h1>
         <label class="form-label">Username</label>
         <input name="writerUsername" type="text" class="form-control" id="validationTooltip01" placeholder="jamesonSelect16">
         <label  class="form-label">full names</label>
         <input name="writerFN" type="text" class="form-control" id="validationTooltip01" placeholder="john jameson">
         <label class="form-label">Company</label>
         <input name="company" type="text" class="form-control" id="validationTooltip01" placeholder="designFX">
         <label  class="form-label">Password</label>
         <input name="writerPassword" type="password" class="form-control" id="validationTooltip01" placeholder="Password">
           <button type="submit" class="btn btn-secondary " style="margin-left:35%; margin-top:10px;" name="update">update</button><br>
       </div>
   </div>
   </form>
   <?php
   if (isset($_POST["update"])) {
     $writerUsername = $_POST['writerUsername'];
     $writerFm = $_POST['writerFN'];
     $company = $_POST['company'];
     $writerPassword = $_POST['writerPassword'];
     //add slashes
     //create an sql statement
     $sql = "UPDATE tblwriters SET Username = '$writerUsername', Name ='$writerFm', CompanyName= '$company', Password = '$writerPassword' WHERE Username ='$details' ";
       //run it
       $result = mysqli_query($connect,$sql);
       echo mysqli_affected_rows($connect);
       if(mysqli_affected_rows($connect) > 0) {

           echo "Data saved successfully";
         }else
         {
           echo mysqli_connect_error();
         }

   }

   if(isset($_GET["delete"]))
    {
     $sql="DELETE FROM tblarticles WHERE `users`.`User_id` = ".$_GET["delete"];
     //running the query
     $results= $connect->query($sql);
   }
   if
     ($connect->affected_rows > 0) {

       $message =$connect->affected_rows."deleted";
     }

    ?>



  </body>
</html>
